import React from 'react';
import { createRoot } from 'react-dom/client';
import { Trophy, Flag, Timer, DollarSign } from 'lucide-react';
import './styles.css';

const currentRace = {
  name: 'FireKeepers Casino 400',
  track: 'Michigan International Speedway',
  location: 'Brooklyn, Michigan',
  date: 'Sunday, June 7, 2026',
  time: '3:00 PM ET',
  laps: '200 laps / 400 miles',
  trackLength: '2.0 miles',
  banking: '18° turns',
};

const lastWinner = {
  name: 'Ryan',
  points: 127,
  prize: '$50',
  drivers: ['#12 Blaney', '#5 Larson', '#24 Byron'],
};

const standings = [
  ['Pat', 487],
  ['Meg', 472],
  ['Darin', 451],
  ['Alz', 445],
  ['Joe', 432],
  ['Evelyn', 417],
  ['Deric', 405],
  ['Josh', 398],
  ['Ryan', 392],
  ['Jay', 381],
];

const weeklyPicks = [
  { player: 'Pat', picks: ['#5 Larson', '#11 Hamlin', '#45 Reddick'] },
  { player: 'Meg', picks: ['#12 Blaney', '#24 Byron', '#1 Chastain'] },
  { player: 'Darin', picks: ['#24 Byron', '#22 Logano', '#21 Berry'] },
  { player: 'Alz', picks: ['#5 Larson', '#12 Blaney', '#2 Cindric'] },
  { player: 'Joe', picks: ['#45 Reddick', '#12 Blaney', '#19 Briscoe'] },
];

function App() {
  const pot = weeklyPicks.length * 5;

  return (
    <main className="page">
      <header className="hero-header">
        <div>
          <p className="eyebrow">Race Day Broadcast Edition</p>
          <h1>Race Shed Fantasy</h1>
          <p className="subtitle">Current Track: {currentRace.track}</p>
        </div>
        <img src="/raceshed-logo.png" alt="Race Shed Logo" className="logo" />
      </header>

      <section className="race-card">
        <div>
          <p className="eyebrow red">Next Race</p>
          <h2>{currentRace.name}</h2>
          <p>{currentRace.track} · {currentRace.location}</p>
          <p>{currentRace.date} · {currentRace.time}</p>
        </div>
        <div className="track-box">
          <Flag size={42} />
          <strong>{currentRace.track}</strong>
          <span>{currentRace.laps}</span>
          <span>{currentRace.trackLength} · {currentRace.banking}</span>
        </div>
      </section>

      <section className="grid">
        <div className="panel winner">
          <Trophy size={34} />
          <p className="eyebrow">Last Week's Winner</p>
          <h3>{lastWinner.name}</h3>
          <p className="big">{lastWinner.points} pts</p>
          <p className="cash">Won {lastWinner.prize}</p>
          <p>{lastWinner.drivers.join(' · ')}</p>
        </div>

        <div className="panel pot">
          <DollarSign size={34} />
          <p className="eyebrow">This Week's Pot</p>
          <h3>${pot}</h3>
          <p>{weeklyPicks.length} players × $5</p>
          <p className="deadline">Picks due Sunday at noon</p>
        </div>
      </section>

      <section className="columns">
        <div className="panel">
          <h3>Current Standings</h3>
          <div className="standings">
            {standings.map(([name, points], index) => (
              <div className="standing-row" key={name}>
                <span>{index + 1}</span>
                <strong>{name}</strong>
                <em>{points}</em>
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <h3>This Week's Picks</h3>
          <div className="picks">
            {weeklyPicks.map((entry) => (
              <div className="pick-card" key={entry.player}>
                <strong>{entry.player}</strong>
                <span>{entry.picks.join('  |  ')}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="ticker">
        <Timer size={20} />
        <span>Larson won Kansas</span>
        <span>Ryan won $50</span>
        <span>Next race: Michigan</span>
        <span>Picks due Sunday noon</span>
      </footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
